aws_region   = "ap-south-1"
project_name = "myapp"
environment  = "dev"

# --- Network ---
vpc_cidr                  = "10.0.0.0/16"
az_count                  = 2
public_subnet_cidrs       = ["10.0.0.0/24", "10.0.1.0/24"]
private_app_subnet_cidrs  = ["10.0.10.0/24", "10.0.11.0/24"]
private_db_subnet_cidrs   = ["10.0.20.0/24", "10.0.21.0/24"]
single_nat_gateway         = true # one NAT gateway shared across AZs - cheaper for dev

# --- ECS: small footprint ---
container_image = "public.ecr.aws/nginx/nginx:stable"
container_port  = 80
task_cpu        = "256"  # 0.25 vCPU
task_memory     = "512"  # 512 MiB
desired_count   = 1
log_retention_days = 7

# --- RDS: small instance, short backups, deletion protection OFF ---
db_engine                       = "postgres"
db_engine_version               = "16.4"
db_instance_class               = "db.t4g.micro"
db_allocated_storage            = 20
db_max_allocated_storage        = 50
db_multi_az                     = false
db_backup_retention_period      = 1
db_deletion_protection          = false
db_skip_final_snapshot          = true
db_performance_insights_enabled = false

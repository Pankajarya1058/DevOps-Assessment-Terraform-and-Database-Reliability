aws_region   = "ap-south-1"
project_name = "myapp"
environment  = "prod"

# --- Network ---
vpc_cidr                  = "10.1.0.0/16"
az_count                  = 2
public_subnet_cidrs       = ["10.1.0.0/24", "10.1.1.0/24"]
private_app_subnet_cidrs  = ["10.1.10.0/24", "10.1.11.0/24"]
private_db_subnet_cidrs   = ["10.1.20.0/24", "10.1.21.0/24"]
single_nat_gateway         = false # one NAT gateway per AZ - HA for prod

# --- ECS: larger footprint, more replicas ---
container_image = "public.ecr.aws/nginx/nginx:stable" # replace with your real ECR image
container_port  = 80
task_cpu        = "1024" # 1 vCPU
task_memory     = "2048" # 2 GiB
desired_count   = 3
log_retention_days = 90

# --- RDS: larger instance, long backups, deletion protection ON ---
db_engine                       = "postgres"
db_engine_version               = "16.4"
db_instance_class               = "db.r6g.large"
db_allocated_storage            = 100
db_max_allocated_storage        = 500
db_multi_az                     = true
db_backup_retention_period      = 30
db_deletion_protection          = true
db_skip_final_snapshot          = false
db_performance_insights_enabled = true
